import os
import re
import sys
from collections import Counter

# -------------------------- 文本归一化 --------------------------
FILLER_WORDS = {"um", "uh", "ah", "er", "hm", "hmm", "uhh", "umm", "oh", "yeah", "right"}
PUNCT_RE = re.compile(r'[^\w\s\']')
MULTI_SPACE = re.compile(r'\s+')

def normalize_text(text):
    """统一归一化：小写、去标点、去冗余空格、可选去填充词"""
    text = text.lower()
    text = PUNCT_RE.sub(' ', text)  # 所有标点替换为空格
    text = MULTI_SPACE.sub(' ', text).strip()
    words = text.split()
    words = [w for w in words if w not in FILLER_WORDS]
    return words

# -------------------------- 读取文件 --------------------------
def read_reference(path):
    """读取参考文本，归一化"""
    with open(path, 'r', encoding='utf-8') as f:
        raw = f.read()
    return normalize_text(raw)

def read_asr_output(path):
    """读取ASR输出，自动剥离所有时间戳，支持单行/多行/各种时间格式"""
    with open(path, 'r', encoding='utf-8') as f:
        raw = f.read()
    # 全局匹配所有时间戳块：[任意时间格式]，不管在什么位置
    # 兼容[00:00:00,000 - 00:00:01,500]、[12.345 - 45.678]等所有变体
    # 用re.escape自动转义方括号，避免手写反斜杠在Windows粘贴时丢失/被吃掉
    timestamp_pattern = re.compile(re.escape('[') + r'[\d:.,\s-]+' + re.escape(']'))
    raw = timestamp_pattern.sub(' ', raw)
    print(raw)
    return normalize_text(raw)


# -------------------------- WER计算（标准Levenshtein动态规划） --------------------------
def calc_wer(ref, hyp):
    """
    返回: (S替换, D删除, I插入, WER值)
    算法：标准编辑距离，S/D/I对应三类错误
    """
    n = len(ref)
    m = len(hyp)
    dp = [[0]*(m+1) for _ in range(n+1)]
    back = [[None]*(m+1) for _ in range(n+1)]
    
    for i in range(n+1):
        dp[i][0] = i
        back[i][0] = 'D'
    for j in range(m+1):
        dp[0][j] = j
        back[0][j] = 'I'
    
    for i in range(1, n+1):
        for j in range(1, m+1):
            if ref[i-1] == hyp[j-1]:
                dp[i][j] = dp[i-1][j-1]
                back[i][j] = 'C'  # 正确
            else:
                sub = dp[i-1][j-1] + 1
                del_ = dp[i-1][j] + 1
                ins = dp[i][j-1] + 1
                min_val = min(sub, del_, ins)
                dp[i][j] = min_val
                if min_val == sub:
                    back[i][j] = 'S'
                elif min_val == del_:
                    back[i][j] = 'D'
                else:
                    back[i][j] = 'I'
    
    # 回溯统计S/D/I
    S = D = I = 0
    i, j = n, m
    while i > 0 or j > 0:
        op = back[i][j]
        if op == 'C':
            i -= 1
            j -= 1
        elif op == 'S':
            S += 1
            i -= 1
            j -= 1
        elif op == 'D':
            D += 1
            i -= 1
        elif op == 'I':
            I += 1
            j -= 1
    
    wer = (S + D + I) / n * 100 if n > 0 else float('inf')
    return S, D, I, wer

# -------------------------- 主程序 --------------------------
def main():
    if len(sys.argv) != 3:
        print("用法：python 评估词错率.py <识别输出_en.txt路径> <参考文本.txt路径>")
        print("示例：python 评估词错率.py 英文会议_近场_3分钟_en.txt 参考文本\\IS1000a_参考文本_前3分钟_归一化.txt")
        sys.exit(1)
    
    asr_path = sys.argv[1]
    ref_path = sys.argv[2]
    
    if not os.path.exists(asr_path):
        print(f"❌ 错误：找不到识别文件 {asr_path}")
        sys.exit(1)
    if not os.path.exists(ref_path):
        print(f"❌ 错误：找不到参考文件 {ref_path}")
        sys.exit(1)
    
    ref_words = read_reference(ref_path)
    hyp_words = read_asr_output(asr_path)
    S, D, I, wer = calc_wer(ref_words, hyp_words)
    
    print("="*60)
    print("词错率评估结果")
    print("="*60)
    print(f"识别文件    : {os.path.basename(asr_path)}")
    print(f"参考文件    : {os.path.basename(ref_path)}")
    print("-"*60)
    print(f"参考词数    : {len(ref_words)}")
    print(f"识别词数    : {len(hyp_words)}")
    print("-"*60)
    print(f"替换 S      : {S}")
    print(f"删除 D      : {D}")
    print(f"插入 I      : {I}")
    print(f"总错误 S+D+I: {S+D+I}")
    print("-"*60)
    print(f"词错率 WER  : {wer:.2f}%")
    print("-"*60)
    
    if wer < 5:
        comment = "极佳，几乎不需要校对"
    elif wer < 10:
        comment = "很好，稍作校对即可直接使用"
    elif wer < 20:
        comment = "可用，需要少量校对"
    elif wer < 40:
        comment = "一般，需要较多校对，适合做速记底稿"
    else:
        comment = "基本不可用，建议换模型或改用更干净的音频"
    print(f"评价：{comment}")
    print("="*60)

if __name__ == "__main__":
    main()
